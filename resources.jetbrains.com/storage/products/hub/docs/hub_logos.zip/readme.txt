
DO’s
----

Do use the logos to link to JetBrains website

Do use the logos to advertise that your product has built-in integration with a JetBrains product

Do use the graphics in printed or online materials



Don’ts
------

Don’t change the colors of the logos

Don’t change the aspect ratio of the logos when resizing

Don’t sell our logos



If in doubt, please contact marketing@jetbrains.com




--
Thank you!
The JetBrains Team